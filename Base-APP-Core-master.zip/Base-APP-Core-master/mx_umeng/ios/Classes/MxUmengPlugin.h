#import <Flutter/Flutter.h>

@interface MxUmengPlugin : NSObject<FlutterPlugin>
@end

#import "MxUmengPlugin.h"
#import <mx_umeng/mx_umeng-Swift.h>
#import <UMCommon/UMCommon.h>
#import <UMPush/UMessage.h>
#import <UserNotifications/UserNotifications.h>

/// 友盟為 oc lib, 目前 swift 不支持 oc 與 swift 頭橋接, 只能暫時寫在 oc 裡

/// 假如 ios sdk 超過 10, 則使用 UNUserNotificationCenterDelegate
#if defined(__IPHONE_10_0) && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_10_0
@interface MxUmengPlugin () <UNUserNotificationCenterDelegate>
@end

#endif

@implementation MxUmengPlugin {

    /// 與 flutter 溝通通道
    FlutterMethodChannel *_channel;

    /// 啟動參數
    NSDictionary *_launchNotification;

    /// 應用是否在後台
    BOOL _resumingFromBackground;
}

+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {

    // 目前 swift 是無用的, 因此在此處做處理
//  [SwiftMxUmengPlugin registerWithRegistrar:registrar];
    FlutterMethodChannel *channel = [FlutterMethodChannel
                                     methodChannelWithName:@"mx_umeng"
                                     binaryMessenger:[registrar messenger]];
    MxUmengPlugin *instance = [[MxUmengPlugin alloc] initWithChannel:channel];
    [registrar addMethodCallDelegate:instance channel:channel];
    [registrar addApplicationDelegate:instance];
}

/// 初始化通套相關
- (instancetype)initWithChannel:(FlutterMethodChannel *)channel {
    self = [super init];
    if (self) {
        _channel = channel;
        _resumingFromBackground = NO;
    }
    return self;
}

/// flutter 呼叫
- (void)handleMethodCall:(FlutterMethodCall *)call result:(FlutterResult)result {
    NSLog(@"mx_umeng 呼叫 handleMethodCall: %@", [call method]);
    NSString *method = call.method;
    if ([@"configure" isEqualToString:method]) {
//        [[UIApplication sharedApplication] registerForRemoteNotifications];
        if (_launchNotification != nil) {
            [_channel invokeMethod:@"onLaunch" arguments:_launchNotification];
        }
        result(nil);
    }else if([@"test" isEqualToString:method]) {
        result(@"hello");
    }else {
        result(FlutterMethodNotImplemented);
    }
}

/// 將接收到的 推送資料轉成 json 字串
- (NSString *)convertToJsonData:(NSDictionary *)dict {
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:nil error:&error];
    NSString *jsonString;
    if (!jsonData) {
        NSLog(@"%@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}

/// 當收到遠端推播時
- (void)didReceiveRemoteNotification:(NSDictionary *)userInfo {
    NSLog(@"mx_umeng 呼叫 didReceiveRemoteNotification userInfo: %@", userInfo);
    NSLog(@"mx_umeng 開始回調 onMessage: %@", _channel);
    [_channel invokeMethod:@"onMessage" arguments:[self convertToJsonData:userInfo]];
}

/// app啟動入口, 在此處初始化友盟
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSLog(@"mx_umeng 呼叫 application didFinishLaunchingWithOptions %@", _launchNotification);
    /// 設置友盟推播
    UMessageRegisterEntity *entity = [[UMessageRegisterEntity alloc] init];

    /// type針對推送要開啟的功能(聲音/彈窗/圖標), 默認全開
    entity.types = UMessageAuthorizationOptionBadge | UMessageAuthorizationOptionAlert;

    /// 開 ios 版本高過 10, 則再加上註冊 UNUserNotificationCenter
    if (@available(iOS 10.0, *)) {
        [UNUserNotificationCenter currentNotificationCenter].delegate = self;
    }

    /// 註冊友盟推送
    [UMessage registerForRemoteNotificationsWithLaunchOptions:launchOptions Entity:entity completionHandler:^(BOOL granted, NSError *_Nullable error) {
        if (granted) {
            NSLog(@"mx_umeng 友盟註冊推送完成");
        } else {
            NSLog(@"mx_umeng 友盟註冊推送失敗");
        }
    }];
    _launchNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    return YES;
}

/// 應用進入後台
- (void)applicationDidEnterBackground:(UIApplication *)application {
    _resumingFromBackground = YES;
    NSLog(@"mx_umeng 呼叫 applicationDidEnterBackground");
}

/// 應用回到前台
- (void)applicationDidBecomeActive:(UIApplication *)application {
    _resumingFromBackground = NO;
    NSLog(@"mx_umeng 呼叫 applicationDidBecomeActive");
//    application.applicationIconBadgeNumber = 0;
}

//iOS10新增 - 前台收到通知時呼叫此方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler  API_AVAILABLE(ios(10.0)){
    NSLog(@"mx_umeng 呼叫 userNotificationCenter willPresentNotification");
    NSDictionary *userInfo = notification.request.content.userInfo;
    if ([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        [UMessage setAutoAlert:NO];
        /// 前台收到遠程推送
        /// 此代碼必加 [self didReceiveRemoteNotification:userInfo];
        /// 將推播訊息打回給 flutter 代碼
        [self didReceiveRemoteNotification:userInfo];
    } else {
        /// 前台收到本地推送
    }
    completionHandler(UNNotificationPresentationOptionSound | UNNotificationPresentationOptionBadge | UNNotificationPresentationOptionAlert);
}

//iOS10新增 - 後台點擊通知時呼叫此方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler  API_AVAILABLE(ios(10.0)){
    NSLog(@"mx_umeng 呼叫 userNotificationCenter didReceiveNotificationResponse");
    NSDictionary *userInfo = response.notification.request.content.userInfo;
    if ([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        /// 後台收到遠程推送
        /// 此代碼必加 [self didReceiveRemoteNotification:userInfo];
        /// 將推播訊息打回給 flutter 代碼
        [self didReceiveRemoteNotification:userInfo];
    } else {
        /// 後台收到本地推送
    }
}

/// 將 NSData 類型的 deviceToken 轉換為字串
- (NSString *)stringDevicetoken:(NSData *)deviceToken {
    NSString *token = [deviceToken description];
    NSString *pushToken = [[[token stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""] stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSLog(@"mx_umeng 轉換 token: %@", pushToken);
    return pushToken;
}

/// 靜默推送打到此方法
- (BOOL)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    NSLog(@"mx_umeng 呼叫 application didReceiveRemoteNotification");
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateActive) {
        // 應用在前台, 接收到靜默推送
    }
    else if (state == UIApplicationStateInactive) {
        // 應用在後台, 點擊通知
    }
    else if (state == UIApplicationStateBackground) {
        // 應用在後台, 點擊收到靜默通知
    }

    /// 將推播訊息打回給 flutter 代碼
    [self didReceiveRemoteNotification:userInfo];

    /// 加上此代碼才會進入
    completionHandler(UIBackgroundFetchResultNewData);

    return YES;
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    NSLog(@"mx_umeng 呼叫 application didRegisterForRemoteNotificationsWithDeviceToken%@", deviceToken);
    [_channel invokeMethod:@"onToken" arguments:[self stringDevicetoken:deviceToken]];
}

@end


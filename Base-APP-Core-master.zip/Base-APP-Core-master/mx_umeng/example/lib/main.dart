import 'package:flutter/material.dart';
import 'dart:async';

import 'package:flutter/services.dart';

import 'package:mx_umeng/mx_umeng.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final MxUmeng _mxUmeng = MxUmeng();

  String _message;

  @override
  void initState() {
    super.initState();

    print("MyApp 進入 initState");

    initPlatformState();
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> initPlatformState() async {

    print("推送註冊");
    _mxUmeng.registerRemoteNotification(
      onLaunch: (message) {
        print("推送(onLaunch): $message");
        updateMessage(message);
      },
      onMessage: (message) {
        print("推送(onMessage): $message");
        updateMessage(message);
      },
      onResume: (message) {
        print("推送(onResume): $message");
        updateMessage(message);
      },
      onToken: (message) {
        print("推送(onToken): $message");
        updateMessage(message);
      },
    );

    if (!mounted) return;
  }

  updateMessage(String message) {
    setState(() {
      _message = message;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Plugin example app'),
        ),
        body: Center(
          child: Text('Message: $_message\n'),
        ),
      ),
    );
  }
}

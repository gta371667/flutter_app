package com.xing.mx_umeng_example

import android.os.Bundle

import io.flutter.app.FlutterActivity
import io.flutter.plugins.GeneratedPluginRegistrant

class MainActivity: FlutterActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    println("MainActivity 進入 onCreate")
    GeneratedPluginRegistrant.registerWith(this)
  }
}

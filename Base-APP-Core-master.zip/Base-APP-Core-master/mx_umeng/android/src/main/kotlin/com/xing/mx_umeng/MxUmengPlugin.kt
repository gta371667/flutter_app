package com.xing.mx_umeng

import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.Registrar

class MxUmengPlugin: MethodCallHandler {

  var channel: MethodChannel? = null

  companion object {

    private var registrar: Registrar? = null
    var instance: MxUmengPlugin? = null

    @JvmStatic
    fun registerWith(registrar: Registrar) {
      println("MxUmengPlugin 註冊")
      MxUmengPlugin.registrar = registrar

      MxUmengPlugin.instance = MxUmengPlugin()
      MxUmengPlugin.instance?.channel = MethodChannel(registrar.messenger(), "mx_umeng")
      MxUmengPlugin.instance?.channel!!.setMethodCallHandler(MxUmengPlugin.instance!!)
    }
  }

  override fun onMethodCall(call: MethodCall, result: Result) {
    println("MxUmengPlugin 呼叫 ${call.method}")
//    result.success("")
    when (call.method) {
      "configure" -> {
        // 当通过友盟离线唤醒的时候，系统首先执行的是UmengOtherPushActivity，而MainActivity尚未启动
        // ，所以UmengApplication的onCreate函数执行友盟注册时，Flutter尚未准备完成，不能接收信息，
        // 为了防止丢失通知，先缓存到SharedPreferences，等flutter初始化完成后，
        // 调用configure函数时，才执行onToken或onMessage回调

        // 檢查缓存是否存在Token，存在在执行Flutter的回调函数onToken，通知flutter进行更新
        val token = PushDataStorage.load(registrar!!.activity(), PushDataStorage.KEY_DEVICE_TOKEN)
        if (!token.isNullOrEmpty()) {
          channel!!.invokeMethod("onToken", token, object : Result {
            override fun success(o: Any?) {
              /// token 成功回調出去, 刪除此數據
              PushDataStorage.save(
                      registrar!!.activity(),
                      PushDataStorage.KEY_DEVICE_TOKEN,
                      null
              )
            }

            override fun error(s: String, s1: String?, o: Any?) {

            }

            override fun notImplemented() {

            }
          })
        }

        // 檢查缓存是否存在推送資料, 若存在回调
        val umsgPushMsg = PushDataStorage.load(registrar!!.activity(), PushDataStorage.KEY_DEVICE_TOKEN)
        if (umsgPushMsg != null && umsgPushMsg != "") {
          channel!!.invokeMethod("onMessage", umsgPushMsg, object : Result {
            override fun success(o: Any?) {
              /// 推送資料 成功回調出去, 刪除此數據
              PushDataStorage.save(
                      registrar!!.activity(),
                      PushDataStorage.KEY_PUSH_MESSAGE,
                      null
              )
            }

            override fun error(s: String, s1: String?, o: Any?) {

            }

            override fun notImplemented() {

            }
          })
        }
        result.success(null)
      }

      else -> {
        result.notImplemented()
      }
    }
  }
}

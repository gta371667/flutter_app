package com.xing.mx_umeng

import android.content.Context
import android.content.SharedPreferences

class PushDataStorage {
    companion object {

        var KEY_PUSH_MESSAGE = "umeng_push_message"
        var KEY_DEVICE_TOKEN = "device_token"

        /// 儲存推送資料
        fun save(context: Context, key: String, value: String?) {
            val userSettings = context.getSharedPreferences("mx_umeng_push_data", 0)
            val editor = userSettings.edit()
            editor.putString(key, value)
            editor.commit()
            println("push message 廠商通道保存推送數據成功")
        }

        /// 讀取推送資料
        fun load(context: Context, key: String): String? {
            val userSettings = context.getSharedPreferences("mx_umeng_push_data", 0)
            return userSettings.getString(key, null)
        }
    }
}
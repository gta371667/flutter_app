package com.xing.mx_umeng

import android.app.Notification
import android.content.Context
import com.google.gson.Gson
import com.umeng.commonsdk.UMConfigure
import com.umeng.message.*
import com.umeng.message.entity.UMessage
import io.flutter.plugin.common.MethodChannel
import org.android.agoo.xiaomi.MiPushRegistar

class MxUmengApplication : io.flutter.app.FlutterApplication() {

    companion object {
        /// 將接收到的推送回傳給 flutter
        val flutterMethodCallback: MethodChannel.Result = object : MethodChannel.Result {
            override fun notImplemented() {
                println("MxUmengApplication 回呼flutter結果 notImplemented")
            }

            override fun error(p0: String?, p1: String?, p2: Any?) {
                println("MxUmengApplication 回呼flutter結果 error $p0, $p1, $p2")
            }

            override fun success(p0: Any?) {
                println("MxUmengApplication 回呼flutter結果 success $p0")
            }
        }
    }

    private val umengAppKey: String
        get() {
            return MxMetaData.metaValue(this, MxMetaData.KEY_UMENG_APPKEY)
        }

    private val umengSecret: String
        get() {
            return MxMetaData.metaValue(this, MxMetaData.KEY_UMENG_MESSAGE_SECRET)
        }

    private val xiaomiId: String
        get() {
            return MxMetaData.metaValue(this, MxMetaData.KEY_XIAOMI_ID).substring(1)
        }

    private val xiaomiKey: String
        get() {
            return MxMetaData.metaValue(this, MxMetaData.KEY_XIAOMI_APPKEY).substring(1)
        }

    override fun onCreate() {
        super.onCreate()
        println("MxUmengApplication 呼叫")
        initUmeng()
    }

    /// 友盟相關設定
    private fun initUmeng() {
        // 先初始化基礎組建, 相關訊息可在 應用管理 -> 應用信息 中找到 (http://message.umeng.com/list/apps)
        // [必] 參數一：當前上下文
        // [必] 參數二：申請應用的AppKey(需替换) (替换为Appkey,服务后台位置：应用管理 -> 应用信息 -> Appkey)
        // 參數三：渠道名稱
        // [必] 參數四：裝置類型, 手機(默認) - UMConfigure.DEVICE_TYPE_PHONE, 盒子 - UMConfigure.DEVICE_TYPE_BOX
        // [必] 參數五：Push推送的secret, 填入Umeng Message Secret對應訊息(需替换) (替换为秘钥信息,服务后台位置：应用管理 -> 应用信息 -> Umeng Message Secret)
        UMConfigure.init(
                this,
                umengAppKey,
                "Umeng",
                UMConfigure.DEVICE_TYPE_PHONE,
                umengSecret
        )

        // 推播相關
        val pushAgent = PushAgent.getInstance(this)

        // 設置badge
//        pushAgent.displayNotificationNumber = 10

        // 自定義 app處於前台時 通知欄是否顯示
        pushAgent.setNotificaitonOnForeground(true)

        // 通知聲音
        // 1. MsgConstant.NOTIFICATION_PLAY_SDK_ENABLE -> 開啟
        // 2. MsgConstant.NOTIFICATION_PLAY_SDK_DISABLE -> 關閉
        // 3. MsgConstant.NOTIFICATION_PLAY_SERVER -> 由伺服器控制
        pushAgent.notificationPlaySound = MsgConstant.NOTIFICATION_PLAY_SDK_ENABLE

        // 自定义通知栏样式
        // 官方說明
        // UmengMessageHandler类负责处理消息，包括通知和自定义消息。
        // 其中，成员函数getNotification负责定义通知栏样式。
        // 若SDK默认的消息展示样式不符合开发者的需求，可通过覆盖该方法来自定义通知栏展示样式。
        val messageHandler = object : UmengMessageHandler() {

            // 自定义通知栏样式
            // 官方說明
            // 在PushSDK里，UmengMessageHandler类负责处理消息，包括通知和自定义消息。
            // 其中，成员函数getNotification负责定义通知栏样式。
            // 若SDK默认的消息展示样式不符合开发者的需求，可通过覆盖该方法来自定义通知栏展示样式。
            override fun getNotification(p0: Context?, p1: UMessage?): Notification {
                return super.getNotification(p0, p1)
            }

            // 自定义消息（消息透传）
            // 官方說明
            // 自定义消息可以用于应用的内部业务逻辑和特殊展示需求。
            // 自定义消息不是通知，默认不会被SDK展示到通知栏上
            // 【友盟+】推送仅负责将消息透传给SDK，其内容和展示形式是则完全可以由开发者自己定义
            override fun dealWithCustomMessage(p0: Context?, p1: UMessage?) {
                super.dealWithCustomMessage(p0, p1)
            }
        }
//        pushAgent.messageHandler = messageHandler


        // 自定义通知栏打开动作
        // 官方說明
        // 开发者可自定义用户点击通知栏时的后续动作。
        // 自定义行为的数据放在UMessage.custom字段。
        // 在【友盟+】后台或通过API发送消息时，在“后续动作”中的“自定义行为”中输入相应的值或代码即可实现。
        // 若开发者需要处理自定义行为，则可以重写方法dealWithCustomAction()。
        // 其中自定义行为的内容，存放在UMessage.custom中。

        // 這邊複寫下列方法, 將點擊通知的訊息傳回flutter
        val notificationClickHandler = object : UmengNotificationClickHandler() {
            override fun launchApp(context: Context, uMessage: UMessage?) {
                val umengPushMsg = formatMsg(uMessage)
                println("MxUmengApplication 呼叫 launchApp $umengPushMsg")
                MxUmengPlugin.instance?.channel?.invokeMethod("onMessage", umengPushMsg, MxUmengApplication.flutterMethodCallback)
                super.launchApp(context, uMessage)
            }

            override fun openUrl(context: Context, uMessage: UMessage) {
                val umengPushMsg = formatMsg(uMessage)
                println("MxUmengApplication 呼叫 openUrl $umengPushMsg")
                MxUmengPlugin.instance?.channel?.invokeMethod(
                        "onMessage",
                        umengPushMsg,
                        MxUmengApplication.flutterMethodCallback)
                super.openUrl(context, uMessage)
            }

            override fun openActivity(context: Context, uMessage: UMessage) {
                val umengPushMsg = formatMsg(uMessage)
                println("MxUmengApplication 呼叫 openActivity $umengPushMsg")
                MxUmengPlugin.instance?.channel?.invokeMethod(
                        "onMessage",
                        umengPushMsg,
                        MxUmengApplication.flutterMethodCallback)
                super.openActivity(context, uMessage)
            }

            override fun dealWithCustomAction(context: Context?, uMessage: UMessage?) {
                val umengPushMsg = formatMsg(uMessage)
                println("MxUmengApplication 呼叫 dealWithCustomAction $umengPushMsg")
                MxUmengPlugin.instance?.channel?.invokeMethod(
                        "onMessage",
                        umengPushMsg,
                        MxUmengApplication.flutterMethodCallback)
                super.dealWithCustomAction(context, uMessage)
            }
        }
        pushAgent.notificationClickHandler = notificationClickHandler

        // 推送註冊 (在此可取得 token)
        pushAgent.register(object : IUmengRegisterCallback {
            override fun onSuccess(p0: String?) {
                if (p0.isNullOrBlank()) {
                    println("MxUmengApplication 取得 token onSuccess 失敗")
                    return
                } else {
                    println("MxUmengApplication 取得 token onSuccess = $p0")
                }
                if (MxUmengPlugin.instance != null) {
                    //Flutter插件已经初始化完成，可以直接调用
                    MxUmengPlugin.instance?.channel?.invokeMethod(
                            "onToken",
                            p0,
                            MxUmengApplication.flutterMethodCallback)
                } else { //Flutter尚未初始化（主要原因是使用小米、华为、魅族的离线唤醒方式初始化的，首先执行的的UmengOtherPushActivity）
                    //缓存
                    PushDataStorage.save(applicationContext, PushDataStorage.KEY_DEVICE_TOKEN, p0)
                }
            }

            override fun onFailure(p0: String?, p1: String?) {
                println("MxUmengApplication 註冊 token onFailure 失敗")
            }

        })

        pushAgent.onAppStart()

        // 小米Push初始化
        // 注意
        // 1. 仅在小米MIUI设备上生效。
        // 2. 集成小米push的版本暂不支持多包名。
        MiPushRegistar.register(this, xiaomiId, xiaomiKey)

        println("註冊友盟 appKey $umengAppKey, secret: $umengSecret")
        println("註冊小米 id: $xiaomiId, key: $xiaomiKey")
    }

    fun formatMsg(uMessage: UMessage?): String {
        if (uMessage == null) return ""
        return Gson().toJson(uMessage, UMessage::class.java)
    }
}

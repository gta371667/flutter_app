package com.xing.mx_umeng

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Message
import com.umeng.message.UmengNotifyClickActivity
import org.android.agoo.common.AgooConstants

/// 各大廠商通道(小米/華為)
class MxUmengActivity: UmengNotifyClickActivity() {

    @SuppressLint("HandlerLeak")
    private val handler = object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            val umengPushMsg = msg.obj as String

            // Activity 可能上未初始化, 先存入本地
            PushDataStorage.save(this@MxUmengActivity, PushDataStorage.KEY_PUSH_MESSAGE, umengPushMsg)
            println("MxUmengActivity 處理推送資料: $umengPushMsg")
            val context = this@MxUmengActivity.applicationContext

            // 獲取 url scheme, 以此開啟app
            val scheme = MxMetaData.metaValue(this@MxUmengActivity, MxMetaData.KEY_URL_SCHEME)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("$scheme://"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            finish()
        }
    }

    override fun onCreate(p0: Bundle?) {
        super.onCreate(p0)
        println("MxUmengActivity 進入 onCreate")
    }

    /// 小米離線喚醒
    /// 官方說明
    /// 小米对后台进程做了诸多限制。若使用一键清理，应用的channel进程被清除，将接收不到推送。
    /// 通过接入小米托管弹窗功能，可有效防止以上情况，增加推送消息的送达率。
    /// 通知将由小米系统托管弹出，点击通知栏将跳转到指定的Activity。
    /// 该Activity需继承自UmengNotifyClickActivity，同时实现父类的onMessage方法，
    /// 对该方法的intent参数进一步解析即可，该方法异步调用，不阻塞主线程。
    override fun onMessage(p0: Intent?) {
        super.onMessage(p0)
        println("MxUmengActivity 離線喚醒 onMessage $intent")
        val umengPushMsg = intent.getStringExtra(AgooConstants.MESSAGE_BODY)
        println("MxUmengActivity 離線喚醒 umengPushMsg $umengPushMsg")
        val message = Message.obtain()
        message.obj = umengPushMsg
        handler.sendMessage(message)
    }
}
package com.xing.mx_umeng

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

class MxMetaData {

    companion object {
        /// 需要宣告在 Manifest 的相關變數 key
        val KEY_URL_SCHEME = "MX_URL_SCHEME"

        /// 友盟的APPKEY/MESSAGE_SECRET
        val KEY_UMENG_APPKEY = "MX_UMENG_APPKEY"
        val KEY_UMENG_MESSAGE_SECRET = "MX_UMENG_MESSAGE_SECRET"

        /// 小米的KEY/ID
        val KEY_XIAOMI_ID = "MX_XIAOMI_ID"
        val KEY_XIAOMI_APPKEY = "MX_XIAOMI_APPKEY"

        fun metaValue(context: Context, metaKey: String): String {
            val packageManager = context.packageManager
            try {
                val appInfo: ApplicationInfo? = packageManager.getApplicationInfo(context.packageName,
                        PackageManager.GET_META_DATA)
                var channel: String? = appInfo!!.metaData.get(metaKey)!!.toString()
                if (channel == null || channel == "") {
                    channel = ""
                }
                return channel
            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }

            return ""
        }
    }
}
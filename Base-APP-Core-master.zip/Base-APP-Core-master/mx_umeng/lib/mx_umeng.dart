import 'dart:async';

import 'package:flutter/services.dart';

typedef MessageHandler(String message);

class MxUmeng {
  static const MethodChannel _channel = const MethodChannel('mx_umeng');

  MessageHandler _onMessage;
  MessageHandler _onLaunch;
  MessageHandler _onResume;
  MessageHandler _onToken;

  registerRemoteNotification({
    MessageHandler onMessage,
    MessageHandler onLaunch,
    MessageHandler onResume,
    MessageHandler onToken,
  }) {
    _onMessage = onMessage;
    _onLaunch = onLaunch;
    _onResume = onResume;
    _onToken = onToken;
    _channel.setMethodCallHandler(_handleMethod);
    _channel.invokeMethod("configure");
  }

  Future<Null> _handleMethod(MethodCall call) async {
    switch (call.method) {
      case "onToken":
        final String token = call.arguments;
        print('FlutterUmpush 推送回調 onToken: $token');
        _onToken(token);
        return null;
      case "onMessage":
        final String message = call.arguments;
        print('FlutterUmpush 推送回調 onMessage: $message');
        _onMessage(message);
        return null;
      case "onLaunch":
        final String message = call.arguments;
        print('FlutterUmpush 推送回調 onLaunch: $message');
        _onLaunch(call.arguments.cast<String>());
        return null;
      case "onResume":
        final String message = call.arguments;
        print('FlutterUmpush 推送回調 onResume: $message');
        _onResume(call.arguments.cast<String>());
        return null;
      default:
        throw new UnsupportedError("Unrecognized JSON message");
    }
  }
}

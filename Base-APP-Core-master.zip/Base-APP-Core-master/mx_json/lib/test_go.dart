import 'package:json_annotation/json_annotation.dart';
import 'package:type_translator/type_translator.dart';
part 'test_go.g.dart';

@JsonSerializable()
class TestGoBean {
  @JsonKey(fromJson: translateString, name: "100...test")
  String $100Test;

  TestGoBean({this.$100Test});
  factory TestGoBean.fromJson(dynamic json) =>
      json != null ? _$TestGoBeanFromJson(json) : null;

  dynamic toJson() => _$TestGoBeanToJson(this);
}

#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/magicalwater/sdk/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/magicalwater/FlutterProjects/AppCore-Flutter/mx_json/example"
export "FLUTTER_TARGET=/Users/magicalwater/FlutterProjects/AppCore-Flutter/mx_json/example/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build/ios"
export "FLUTTER_FRAMEWORK_DIR=/Users/magicalwater/sdk/flutter/bin/cache/artifacts/engine/ios"
export "TRACK_WIDGET_CREATION=true"

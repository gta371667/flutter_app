#import <Flutter/Flutter.h>

@interface MxJsonPlugin : NSObject<FlutterPlugin>
@end

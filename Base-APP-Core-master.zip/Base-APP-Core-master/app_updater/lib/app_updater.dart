import 'dart:async';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:rxdart/rxdart.dart';
import 'package:url_launcher/url_launcher.dart';

class AppUpdater {
//  static const MethodChannel _channel = const MethodChannel('app_updater');
//
//  static Future<String> get platformVersion async {
//    final String version = await _channel.invokeMethod('getPlatformVersion');
//    return version;
//  }

  static BehaviorSubject<int> _progressSubject = BehaviorSubject();

  /// 進度百分比 0 ~ 100
  static Stream<int> get progressStream => _progressSubject.stream;

  /// 開始事件監聽
  static PublishSubject<void> _startSubject = PublishSubject();

  /// 結束事件監聽
  static PublishSubject<void> _doneSubject = PublishSubject();

  /// 結束事件監聽, 錯誤事件也在此監聽
  static Stream<void> get doneStream => _doneSubject.stream;

  /// 開始事件監聽
  static Stream<void> get startStream => _startSubject.stream;

  /// 是否正在下載中
  static bool isDownloading = false;

  static const _channelName = 'app_updater';

  /// 事件通道, 取得
  static const _eventChannel = const EventChannel(_channelName);

  /// 下載進度
  static StreamSubscription _downloadSubscription;

  /// 進行更新
  /// ios => 強制使用開啟 web
  /// android => 依據 [openWeb] 來決定是用下載還是開啟web
  static Future<void> update(String url, {bool openWeb = true}) async {
    print("開始更新: $url, 是否為開啟 web: $openWeb");
    // 若 url 無效則拋出錯誤
    if (!(await _isUrlEffect(url))) {
      throw UpdateError.urlFail;
    }

    if (Platform.isIOS) {
      if (!openWeb) {
        print("ios 尚不支持下載ipa更新的方式, 自動更改為開啟 web");
      }
      await launch(url);
    } else if (Platform.isAndroid) {
      if (openWeb) {
        await launch(url);
      } else {
        await _downloadAndroidApk(url);
      }
    } else {
      print("未知系統, 無法進行更新: ${Platform.operatingSystem}");
    }
  }

  /// android 下載
  static Future<void> _downloadAndroidApk(String url) async {
    // 檢查是否有外部 storage 的權限
    print("android 檢查權限");
    var permissions =
        await PermissionHandler().requestPermissions([PermissionGroup.storage]);
    print("擁有的權限: $permissions");

    if (permissions[PermissionGroup.storage] == PermissionStatus.granted) {
      print("擁有讀寫外部儲存空間的權限, 開始下載");
      var receiveStream = _eventChannel.receiveBroadcastStream(url);
      _downloadSubscription = receiveStream
          .listen((event) => _parseDownloadEvent(event), onDone: () {
        print("下載串流結束");
      }, onError: (error) {
        print("下載串流錯誤: $error");
      });

//      print("3秒後斷開平台連接");
//      Future.delayed(Duration(seconds: 3)).then((_) {
//        print("斷開開始");
//        _downloadSubscription?.cancel();
//        print("斷開完成");
//      });
    } else {
      // 沒有權限, 需要打開儲存權限
      throw UpdateError.needExStoragePermission;
    }
  }

  /// 解析下載的回傳事件, 並且放到 subject 打出去
  static void _parseDownloadEvent(dynamic event) {
    if (event is Map) {
      switch (event[EventTag.event]) {
        case Event.start:
          print("下載開始");
          isDownloading = true;
          _startSubject.add('start');
          break;
        case Event.cancel:
          print("下載取消");
          break;
        case Event.progress:
          isDownloading = true;
//          print("下載進度: ${event[EventTag.value]}");
          _progressSubject.add(event[EventTag.value]);
          break;
        case Event.error:
          print("下載失敗");
          isDownloading = false;
          _doneSubject.addError('下载更新失败');
          break;
        case Event.finish:
          print("下載完成");
          isDownloading = false;
          _doneSubject.add('success');
          break;
      }
    }
  }

  /// 檢查 url 是否有效
  static Future<bool> _isUrlEffect(String url) async {
    return await canLaunch(url);
  }

  static void dispose() {
    _downloadSubscription?.cancel();
    _progressSubject.close();
    _doneSubject.close();
    _doneSubject.close();
  }
}

class UpdateError extends Error implements Exception {
  final UpdateErrorType type;

  UpdateError._(this.type);

  static UpdateError urlFail = UpdateError._(UpdateErrorType.urlFail);
  static UpdateError needExStoragePermission =
      UpdateError._(UpdateErrorType.needExStoragePermission);
}

enum UpdateErrorType {
  /// url 無效
  urlFail,

  /// 沒有外部儲存權限
  needExStoragePermission,
}

class EventTag {
  static var event = "event";
  static var value = "value";
}

class Event {
  static const progress = "process";
  static const finish = "finish";
  static const cancel = "cancel";
  static const error = "error";
  static const start = "start";
}

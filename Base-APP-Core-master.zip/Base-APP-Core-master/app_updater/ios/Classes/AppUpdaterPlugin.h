#import <Flutter/Flutter.h>

@interface AppUpdaterPlugin : NSObject<FlutterPlugin>
@end

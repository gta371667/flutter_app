#import "MxIconGeneratorPlugin.h"
#import <mx_icon_generator/mx_icon_generator-Swift.h>

@implementation MxIconGeneratorPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
  [SwiftMxIconGeneratorPlugin registerWithRegistrar:registrar];
}
@end

#import <Flutter/Flutter.h>

@interface MxIconGeneratorPlugin : NSObject<FlutterPlugin>
@end

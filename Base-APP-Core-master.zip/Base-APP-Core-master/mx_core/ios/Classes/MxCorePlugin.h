#import <Flutter/Flutter.h>

@interface MxCorePlugin : NSObject<FlutterPlugin>
@end

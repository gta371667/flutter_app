import 'dart:ui';

class DColors {
  static const exTheme = Color(0xff00ccbb);

  DColors._();
}

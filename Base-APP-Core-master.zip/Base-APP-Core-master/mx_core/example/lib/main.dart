import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:mx_core/mx_core.dart';

import 'bloc/application_bloc.dart';
import 'router/route.dart';

void main() {
//  print("螢幕高: ${Screen.height}");

//  timeDilation = 25;

  // 設定基底初始化
  ProjectCore.setting(
    // 設計稿尺寸
    designSize: DesignSize(414, 896, density: 2),

    // 專案擁有的 route
    routeSetting: RouteSetting(
      mixinImpl: ApplicationBloc.getInstance(),
      widgetImpl: RouteWidget.getInstance(),
    ),
  );
  

  // 設定預設 app bar
  PageScaffold.setDefaultAppBar((context, leading, title, actions) {
    Widget titleWidget = Text(
      title,
      style: TextStyle(
        color: Colors.white,
        fontSize: Screen.scaleA(16),
      ),
    );
    return PreferredSize(
      preferredSize: Size.fromHeight(
        kToolbarHeight,
      ),
      child: AppBar(
        brightness: Brightness.light,
        leading: leading,
        title: titleWidget,
        iconTheme: IconThemeData(
          color: Colors.black,
          size: Screen.scaleA(20),
        ),
        actions: actions,
      ),
    );
  });

  runApp(App());
}

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
//    WebView();
    return LoadProvider(
      root: true,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        onGenerateTitle: (context) {
          return 'MxCore範例';
        },
        theme: ThemeData.from(
          colorScheme: const ColorScheme.light(),
        ).copyWith(
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: <TargetPlatform, PageTransitionsBuilder>{
              TargetPlatform.android: ZoomPageTransitionsBuilder(),
            },
          ),
        ),
        home: ApplicationBloc.getInstance().getPage(
          Pages.introduction,
          entryPoint: true,
        ),
      ),
    );
  }
}

//class BB extends StatefulWidget {
//  @override
//  _BBState createState() => _BBState();
//}
//
//class _BBState extends State<BB> with SingleTickerProviderStateMixin {
//  AnimationController controller;
//
//  @override
//  void initState() {
//    controller = AnimationController(
//      vsync: this,
//      duration: Duration(seconds: 5),
//    );
//
//    Tween<double> tween = DelayTween(begin: 0.0, end: 1.0, delay: 0);
//    Animation<double> animation;
//    animation = tween.animate(controller)
//      ..addListener(() {
//        print('tween = ${animation.value.toStringAsFixed(1)}, ${controller.value.toStringAsFixed(1)}');
//      });
//
//    controller.forward();
//
//    super.initState();
//  }
//
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      body: Container(child: Container()),
//    );
//  }
//}


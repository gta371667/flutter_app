import 'main.dart' as general;

void main() {
  general.main();
}
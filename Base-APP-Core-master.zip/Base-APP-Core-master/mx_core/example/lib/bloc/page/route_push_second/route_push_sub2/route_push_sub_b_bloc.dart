import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class RoutePushSubBBloc extends PageBloc {

  RoutePushSubBBloc(RouteOption option) : super(Pages.routePushSubB, option);

  @override
  void dispose() {
    super.dispose();
  }
}
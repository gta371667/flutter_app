import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class RoutePushSubABloc extends PageBloc {

  RoutePushSubABloc(RouteOption option) : super(Pages.routePushSubA, option);

  @override
  void dispose() {
    super.dispose();
  }
}
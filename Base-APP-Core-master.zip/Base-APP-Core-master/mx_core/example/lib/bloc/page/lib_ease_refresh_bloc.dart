import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class LibEaseRefreshBloc extends PageBloc {

  LibEaseRefreshBloc(RouteOption option) : super(Pages.libEaseRefresh, option);

  @override
  void dispose() {
    super.dispose();
  }
}
import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class RoutePushEntryBloc extends PageBloc {

  RoutePushEntryBloc(RouteOption option) : super(Pages.routePushEntry, option);

  @override
  void dispose() {
    super.dispose();
  }
}
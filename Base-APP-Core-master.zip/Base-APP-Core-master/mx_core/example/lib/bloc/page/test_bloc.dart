import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class TestBloc extends PageBloc {

  TestBloc(RouteOption option) : super(Pages.test, option);

  @override
  void dispose() {
    super.dispose();
  }
}
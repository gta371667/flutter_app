import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class ParticleAnimationBloc extends PageBloc {

  ParticleAnimationBloc(RouteOption option) : super(Pages.particleAnimation, option);

  @override
  void dispose() {
    super.dispose();
  }
}
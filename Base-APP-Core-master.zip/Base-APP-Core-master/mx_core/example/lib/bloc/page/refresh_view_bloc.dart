import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class RefreshViewBloc extends PageBloc {

  RefreshViewBloc(RouteOption option) : super(Pages.refreshView, option);

}
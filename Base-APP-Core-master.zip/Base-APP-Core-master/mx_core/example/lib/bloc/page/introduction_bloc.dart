import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class IntroductionBloc extends PageBloc {
  IntroductionBloc(RouteOption option) : super(Pages.introduction, option);
}

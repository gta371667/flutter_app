import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class WaveProgressBloc extends PageBloc {

  WaveProgressBloc(RouteOption option) : super(Pages.waveProgress, option);

  @override
  void dispose() {
    super.dispose();
  }
}
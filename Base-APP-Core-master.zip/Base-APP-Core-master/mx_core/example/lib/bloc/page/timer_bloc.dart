import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class TimerBloc extends PageBloc {

  TimerBloc(RouteOption option) : super(Pages.timer, option);

  @override
  void dispose() {
    super.dispose();
  }
}
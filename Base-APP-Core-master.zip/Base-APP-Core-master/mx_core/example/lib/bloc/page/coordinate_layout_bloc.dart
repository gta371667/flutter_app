import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class CoordinateLayoutBloc extends PageBloc {

  CoordinateLayoutBloc(RouteOption option) : super(Pages.coordinateLayout, option);

  @override
  void dispose() {
    super.dispose();
  }
}
import 'package:mx_core/mx_core.dart';
import 'package:mx_core_example/router/route.dart';

class StatefulButtonBloc extends PageBloc {

  StatefulButtonBloc(RouteOption option) : super(Pages.statefulButton, option);

  @override
  void dispose() {
    super.dispose();
  }
}
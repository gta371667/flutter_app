abstract class Builder {
  String build();
}
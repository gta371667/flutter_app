enum HttpMethod {
  get,
  post,
  delete,
  put,
  download,
}
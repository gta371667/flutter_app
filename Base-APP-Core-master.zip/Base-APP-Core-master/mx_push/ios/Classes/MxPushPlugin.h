#import <Flutter/Flutter.h>

@interface MxPushPlugin : NSObject<FlutterPlugin>

@end

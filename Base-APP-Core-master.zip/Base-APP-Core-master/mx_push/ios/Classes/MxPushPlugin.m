#import "MxPushPlugin.h"
#import <mx_push/mx_push-Swift.h>
#import <UMCommon/UMCommon.h>
#import <UMPush/UMessage.h>
#import <UserNotifications/UserNotifications.h>

/// 友盟為 oc lib, 目前 swift 不支持 oc 與 swift 頭橋接, 只能暫時寫在 oc 裡

/// 假如 ios sdk 超過 10, 則使用 UNUserNotificationCenterDelegate
#if defined(__IPHONE_10_0) && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_10_0

@interface MxPushPlugin () <UNUserNotificationCenterDelegate>
@end

#endif

/// Flutter 呼叫本地方法
/// 檢查推送狀態
NSString* checkedPushData = @"checkedPushData";

/// 設置推送狀態
NSString *setPushEnable = @"setPushEnable";
//
//    /// 回傳現在推送是否開啟
NSString *isPushEnable = @"isPushEnable";
//
//    /// 回調 Flutter 方法
//    /// app關於通知的啟動參數
NSString *onLaunch = @"onLaunch";
//
//    /// 裝置 token
NSString *onToken = @"onToken";
//
//    /// 推送/透傳消息
NSString *onMessage = @"onToken";
//
//    /// 推送狀態
NSString *onState = @"onState";

@implementation MxPushPlugin {
    
    /// 與 flutter 溝通通道
    FlutterMethodChannel *_channel;
    
    /// app啟動時遠程推送的參數
    NSDictionary *_launchNotification;
    
    /// app啟動時的參數
    NSDictionary *_launchOptions;
    
    /// 應用是否在後台
    BOOL _resumingFromBackground;
}

+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
    
    // 目前 swift 是無用的, 因此在此處做處理
//    [SwiftMxPushPlugin registerWithRegistrar:registrar];
    FlutterMethodChannel *channel = [FlutterMethodChannel
                                     methodChannelWithName:@"mx_push"
                                     binaryMessenger:[registrar messenger]];
    MxPushPlugin *instance = [[MxPushPlugin alloc] initWithChannel:channel];
    [registrar addMethodCallDelegate:instance channel:channel];
    [registrar addApplicationDelegate:instance];
}

/// 初始化通套相關
- (instancetype)initWithChannel:(FlutterMethodChannel *)channel {
    self = [super init];
    if (self) {
        _channel = channel;
        _resumingFromBackground = NO;
    }
    return self;
}

/// flutter 呼叫
- (void)handleMethodCall:(FlutterMethodCall *)call result:(FlutterResult)result {
    NSLog(@"mx_push 呼叫 handleMethodCall: %@", [call method]);
    NSString *method = call.method;
    
    if ([setPushEnable isEqualToString:method]) {
        BOOL enable = call.arguments;
        if (enable) {
            [self registerUmengPush];
        } else {
            [self unregisterUmengPush];
        }
        result(nil);
    }else if([isPushEnable isEqualToString:method]) {
        NSNumber *isEnable = [NSNumber numberWithBool:[self loadPustState]];
        result(isEnable);
    }else if([@"setMiPush" isEqualToString:method]) {
        /// android 才需要這方法, 因此這邊直接回傳處理了就好
        result(nil);
    }else {
        result(FlutterMethodNotImplemented);
    }
}

/// 將接收到的 推送資料轉成 json 字串
- (NSString *)convertToJsonData:(NSDictionary *)dict {
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:nil error:&error];
    NSString *jsonString;
    if (!jsonData) {
        NSLog(@"%@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}

/// 當收到遠端推播時
- (void)didReceiveRemoteNotification:(NSDictionary *)userInfo {
    NSLog(@"mx_push 呼叫 didReceiveRemoteNotification userInfo: %@", userInfo);
    NSLog(@"mx_push 開始回調 onMessage: %@", _channel);
    
    /// 將收到的通知回調給 flutter
    [_channel invokeMethod:onMessage arguments:[self convertToJsonData:userInfo]];
}

/// app啟動入口, 在此處初始化友盟
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSLog(@"mx_push 呼叫 application didFinishLaunchingWithOptions %@", _launchNotification);
    
    /// 開 ios 版本高過 10, 則再加上註冊 UNUserNotificationCenter
    if (@available(iOS 10.0, *)) {
        [UNUserNotificationCenter currentNotificationCenter].delegate = self;
    }
    _launchOptions = launchOptions;
    _launchNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];

    /// 將app關於通知的啟動參數回調
    if (_launchNotification != nil) {
        [_channel invokeMethod:onLaunch arguments:_launchNotification];
    }

    return YES;
}

/// 應用進入後台
- (void)applicationDidEnterBackground:(UIApplication *)application {
    _resumingFromBackground = YES;
    NSLog(@"mx_push 呼叫 applicationDidEnterBackground");
}

/// 應用回到前台
- (void)applicationDidBecomeActive:(UIApplication *)application {
    _resumingFromBackground = NO;
    NSLog(@"mx_push 呼叫 applicationDidBecomeActive");
    //    application.applicationIconBadgeNumber = 0;
}

//iOS10新增 - 前台收到通知時呼叫此方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler  API_AVAILABLE(ios(10.0)){
    NSLog(@"mx_push 呼叫 userNotificationCenter willPresentNotification");
    NSDictionary *userInfo = notification.request.content.userInfo;
    if ([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        [UMessage setAutoAlert:NO];
        /// 前台收到遠程推送
        /// 此代碼必加 [self didReceiveRemoteNotification:userInfo];
        /// 將推播訊息打回給 flutter 代碼
        [self didReceiveRemoteNotification:userInfo];
    } else {
        /// 前台收到本地推送
    }
    completionHandler(UNNotificationPresentationOptionSound | UNNotificationPresentationOptionBadge | UNNotificationPresentationOptionAlert);
}

//iOS10新增 - 後台點擊通知時呼叫此方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler  API_AVAILABLE(ios(10.0)){
    NSLog(@"mx_push 呼叫 userNotificationCenter didReceiveNotificationResponse");
    NSDictionary *userInfo = response.notification.request.content.userInfo;
    if ([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        /// 後台收到遠程推送
        /// 此代碼必加 [self didReceiveRemoteNotification:userInfo];
        /// 將推播訊息打回給 flutter 代碼
        [self didReceiveRemoteNotification:userInfo];
    } else {
        /// 後台收到本地推送
    }
}

/// 將 NSData 類型的 deviceToken 轉換為字串
- (NSString *)stringDevicetoken:(NSData *)deviceToken {
    NSString *token = [deviceToken description];
    NSString *pushToken = [[[token stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""] stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSLog(@"mx_push 轉換 token: %@", pushToken);
    return pushToken;
}

/// 靜默推送打到此方法
- (BOOL)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    NSLog(@"mx_push 呼叫 application didReceiveRemoteNotification");
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateActive) {
        // 應用在前台, 接收到靜默推送
    }
    else if (state == UIApplicationStateInactive) {
        // 應用在後台, 點擊通知
    }
    else if (state == UIApplicationStateBackground) {
        // 應用在後台, 點擊收到靜默通知
    }
    
    /// 將推播訊息打回給 flutter 代碼
    [self didReceiveRemoteNotification:userInfo];
    
    /// 加上此代碼才會進入
    completionHandler(UIBackgroundFetchResultNewData);
    
    return YES;
}

/// 註冊推送後收到的回調(device token)
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    NSLog(@"mx_push 呼叫 application didRegisterForRemoteNotificationsWithDeviceToken%@", deviceToken);
    
    /// 將收到的 token 回調給 flutter
    [_channel invokeMethod:onToken arguments:[self stringDevicetoken:deviceToken]];
    
    /// 向友盟註冊裝置token
    [UMessage registerDeviceToken:deviceToken];
    
    /// 註冊 alias
    //[UMessage setAlias:@"Water" type:@"AliasType.DEV" response:^(id  _Nullable responseObject, NSError * _Nullable error) {
    //    NSLog(@"mx_push 返回 setAlias ---responseObject---%@", responseObject);
    //    NSLog(@"mx_push 返回 setAlias ---error----%@", error);
    //}];
}

/// 設將推送是否開啟的狀態存到本地
- (void)savePustState: (BOOL)enable {
    [[NSUserDefaults standardUserDefaults] setBool:enable forKey:@"pushState"];
    
    // 接著將推送狀態回調 flutter
    NSNumber *isEnable = [NSNumber numberWithBool:enable];
    [_channel invokeMethod:onState arguments:isEnable];
}

/// 取得目前推送是否為開啟的狀態
- (BOOL)loadPustState {
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"pushState"];
}

/// 註冊友盟推送
- (void)registerUmengPush {
    NSLog(@"mx_push 開始註冊友盟遠推送");
    
    /// 設置友盟推播
    UMessageRegisterEntity *entity = [[UMessageRegisterEntity alloc] init];
    
    /// type針對推送要開啟的功能(聲音/彈窗/圖標), 默認全開
    entity.types = UMessageAuthorizationOptionBadge | UMessageAuthorizationOptionAlert;
    
    [self savePustState:YES];
    
    /// 註冊友盟推送
    [UMessage registerForRemoteNotificationsWithLaunchOptions:_launchOptions Entity:entity completionHandler:^(BOOL granted, NSError *_Nullable error) {
        if (granted) {
            NSLog(@"mx_push 友盟遠推送權限獲取完成");
        } else {
            NSLog(@"mx_push 友盟推送權限獲取失敗");
            [self savePustState:NO];
        }
    }];
    
}

/// 取消註冊友盟推送
- (void)unregisterUmengPush {
    NSLog(@"mx_push 取消註冊友盟遠推送");
    [UMessage unregisterForRemoteNotifications];
    [self savePustState:NO];
}

@end


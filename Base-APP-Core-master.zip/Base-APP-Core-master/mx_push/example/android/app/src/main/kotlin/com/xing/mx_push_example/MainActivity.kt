package com.xing.mx_push_example

import android.os.Bundle
import com.xiaomi.mipush.sdk.MiPushClient

import io.flutter.app.FlutterActivity
import io.flutter.plugins.GeneratedPluginRegistrant

class MainActivity: FlutterActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    println("上層專案的 pkg 名: ${this.packageName}")
    GeneratedPluginRegistrant.registerWith(this)
  }
}

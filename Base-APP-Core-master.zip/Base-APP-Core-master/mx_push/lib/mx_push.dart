import 'dart:async';

import 'package:flutter/services.dart';

import 'package:rxdart/rxdart.dart';

class MxPush {
  static final _singleton = MxPush._internal();

  static MxPush getInstance() => _singleton;

  factory MxPush() => _singleton;

  MxPush._internal() {
    _channel.setMethodCallHandler(_handleMethod);
  }

  final MethodChannel _channel = const MethodChannel('mx_push');

  /// 遠端通知/透傳消息 subject
  BehaviorSubject<String> _messageSubject = BehaviorSubject();

  /// app啟動參數 subject
  BehaviorSubject<List<String>> _launchSubject = BehaviorSubject();

  /// 裝置token subject
  BehaviorSubject<String> _tokenSubject = BehaviorSubject();

  /// 推送狀態 subject
  BehaviorSubject<bool> _stateSubject = BehaviorSubject();

  /// 遠端通知/透傳消息 stream
  Stream<String> get messageStream => _messageSubject.stream;

  /// app啟動參數(關於通知) stream
  Stream<List<String>> get appLaunchStream => _launchSubject.stream;

  /// 裝置token stream
  Stream<String> get tokenStream => _tokenSubject.stream;

  /// 推送狀態 stream
  Stream<bool> get stateStream => _stateSubject.stream;

  /// 設置小米推送, 只針對安著
  setMiPush(String appKey, String appId) async {
    final result = await _channel.invokeMethod(
      _NativeCall.setMiPush,
      {
        'appKey': appKey,
        'appId': appId,
      },
    );
  }

  /// 設置推送開啟與否
  setPushEnable(bool isEnable) async {
    final result = await _channel.invokeMethod(
      _NativeCall.setPushEnable,
      isEnable,
    );
  }

  /// 推送現在是否開啟
  Future<bool> isPushEnable() async {
    final result = await _channel.invokeMethod<bool>(
      _NativeCall.isPushEnable,
    );
    return result;
  }

  Future<Null> _handleMethod(MethodCall call) async {
    switch (call.method) {
      case _NativeBack.onToken:
        final String token = call.arguments;
        print('裝置 onToken: $token');
        _tokenSubject.add(token);
        return null;
      case _NativeBack.onMessage:
        final String message = call.arguments;
        print('收到通知(消息) onMessage: $message');
        _messageSubject.add(message);
        return null;
      case _NativeBack.onLaunch:
        List<String> launchParam = call.arguments;
        print('app啟動參數(通知) onLaunch: $launchParam');
        _launchSubject.add(launchParam);
        return null;
      case _NativeBack.onState:
        final bool state = call.arguments;
        print('推送狀態 onState: $state');
        _stateSubject.add(state);
        return null;
      default:
        throw new UnsupportedError("Unrecognized JSON message");
    }
  }
}

/// 調用 Native 的方法名稱
class _NativeCall {
  /// 檢查推送狀態
  static const checkedPushData = "checkedPushData";

  /// 設定小米推送config
  static const setMiPush = "setMiPush";

  /// 設置推送狀態
  static const setPushEnable = "setPushEnable";

  /// 回傳現在推送是否開啟
  static const isPushEnable = "isPushEnable";
}

/// Native 回調的方法名稱
class _NativeBack {
  /// 裝置 token
  static const onToken = "onToken";

  /// 推送/透傳消息
  static const onMessage = "onMessage";

  /// 推送狀態
  static const onState = "onState";

  /// app啟動參數(ios才會回傳)
  static const onLaunch = "onLaunch";
}
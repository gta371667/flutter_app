package com.xing.mx_push

import android.content.Context
import android.content.SharedPreferences

/// 儲存推送狀態 and 暫存推送資料
class PushDataStorage {

    companion object {
        private const val spName = "push_sp"
        private const val stateKey = "push_state"
        private const val dataKey = "push_data"

        private val prefs: SharedPreferences by lazy {
            PushApplication.instance.applicationContext.getSharedPreferences(spName, Context.MODE_PRIVATE)
        }

        fun setState(enabled: Boolean) = with(prefs.edit()) {
            putBoolean(stateKey, enabled).commit()
        }

        fun getState(): Boolean {
            return prefs.getBoolean(stateKey, false)
        }

        fun setPushData(message: String) = with(prefs.edit()) {
            putString(dataKey, message).commit()
        }

        fun getPushData(): String? {
            return prefs.getString(dataKey, null)
        }
    }

}
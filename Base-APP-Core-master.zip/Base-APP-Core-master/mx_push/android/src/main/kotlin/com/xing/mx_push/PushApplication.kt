package com.xing.mx_push

import android.annotation.SuppressLint
import android.app.Application
import com.xiaomi.channel.commonutils.logger.LoggerInterface
import com.xiaomi.mipush.sdk.Logger
import android.app.ActivityManager.RunningAppProcessInfo
import android.os.Process.myPid
import android.content.Context.ACTIVITY_SERVICE
import android.app.ActivityManager
import android.content.Context
import android.os.Process
import com.xiaomi.mipush.sdk.MiPushClient


/// 因为推送服务XMPushService在AndroidManifest.xml中设置为运行在另外一个进程
/// 这导致本Application会被实例化两次，所以我们需要让应用的主进程初始化。
class PushApplication : io.flutter.app.FlutterApplication() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        private var internalInstance: PushApplication? = null

        val instance: PushApplication
            get() {
                return internalInstance!!
            }
    }

    override fun onCreate() {
        super.onCreate()
        if (isMainProcess()) {
            internalInstance = this
        }
        setMiPushLogger()
    }

    /// 設定小米的 log
    private fun setMiPushLogger() {
        val newLogger = object : LoggerInterface {
            override fun setTag(tag: String) {
                // ignore
            }

            override fun log(content: String, t: Throwable) {
                println("小米 error log: $content, error: $t")
            }

            override fun log(content: String) {
                println("小米 log: $content")
            }
        }
        Logger.setLogger(this, newLogger)
    }

    /// 判斷是否為應用的主進程
    private fun isMainProcess(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val processInfos = am.runningAppProcesses
        val mainProcessName = packageName
        val myPid = Process.myPid()
        for (info in processInfos) {
            if (info.pid == myPid && mainProcessName == info.processName) {
                return true
            }
        }
        return false
    }
}
package com.xing.mx_push.mi

data class MiPushConfig(val appId: String, val appKey: String)
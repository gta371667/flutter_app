package com.xing.mx_push

import android.content.Context
import com.xing.mx_push.mi.MiPushConfig
import com.xing.mx_push.mi.MiPushManager

interface PushManagerProtocol {
    var isEnabled: Boolean

    /// 初始化推送元件
    fun init()

    /// 釋放推送元件
    fun release()
}

/// 推送通道
interface VendorPushProtocol<T> : PushManagerProtocol {
    val type: PushType
    val config: T
    val context: Context
}

class PushManager private constructor() : PushManagerProtocol {

    /// 各渠道
    private val vendorMap: MutableMap<PushType, PushManagerProtocol?> = mutableMapOf(
            PushType.MI to null
    )

    companion object {
        private var instance = PushManager()

        fun getInstance(): PushManager {
            return instance
        }
    }

    /// 設定小米
    fun setMi(appId: String, appKey: String): PushManager {
        vendorMap[PushType.MI] = MiPushManager(MiPushConfig(appId, appKey))
        return this
    }

    /// 初始化推送元件
    override fun init() {
        vendorMap.forEach { (_, v) -> v?.init() }
    }

    /// 釋放推送元件
    override fun release() {
        vendorMap.forEach { (_, v) -> v?.release() }
    }

    override var isEnabled: Boolean
        get() {
            return PushDataStorage.getState()
        }
        set(value) {
            vendorMap.forEach { (_, v) -> v?.isEnabled = value }
            PushDataStorage.setState(value)
            MxPushPlugin.instance.flutterBack(FlutterBack.onState, value)
        }
}
package com.xing.mx_push

import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.Registrar

/// flutter 調用本地的方法名稱
class FlutterCall {
    companion object {
        /// 檢查推送狀態
        const val checkedPushData = "checkedPushData"

        /// 設定小米推送config
        const val setMiPush = "setMiPush"

        /// 設置推送狀態
        const val setPushEnable = "setPushEnable"

        /// 回傳現在推送是否開啟
        const val isPushEnable = "isPushEnable"
    }
}

/// 回調 flutter 的方法名稱
class FlutterBack {
    companion object {
        /// 裝置 token
        const val onToken = "onToken"

        /// 推送/透傳消息
        const val onMessage = "onMessage"

        /// 推送狀態
        const val onState = "onState"
    }
}

class MxPushPlugin : MethodCallHandler {

    private var channel: MethodChannel? = null
    private var registrar: Registrar? = null

    private constructor(channel: MethodChannel, registrar: Registrar) {
        this.channel = channel
        this.registrar = registrar
    }

    companion object {

        private var internalInstance: MxPushPlugin? = null
        val instance: MxPushPlugin
            get() {
                return internalInstance!!
            }

        @JvmStatic
        fun registerWith(registrar: Registrar) {
            val channel = MethodChannel(registrar.messenger(), "mx_push")
            val ins = MxPushPlugin(channel, registrar)
            internalInstance = ins
            channel.setMethodCallHandler(ins)
        }
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        when (call.method) {
            FlutterCall.checkedPushData -> {
                // 當透過離線喚醒時, 系統優先執行 指定的 Activity, 而上層專案的 Activity 尚未啟動
                // 所以註冊的 Device Token
                // 当通过友盟离线唤醒的时候，系统首先执行的是UmengOtherPushActivity，而MainActivity尚未启动
                // ，所以UmengApplication的onCreate函数执行友盟注册时，Flutter尚未准备完成，不能接收信息，
                // 为了防止丢失通知，先缓存到SharedPreferences，等flutter初始化完成后，
                // 调用configure函数时，才执行onToken或onMessage回调

                // 檢查缓存是否存在Token，存在在执行Flutter的回调函数onToken，通知flutter进行更新
                val token = PushDataStorage.getPushData()
//                if (!token.isNullOrEmpty()) {
//                    channel!!.invokeMethod("onToken", token, object : Result {
//                        override fun success(o: Any?) {
//                            /// token 成功回調出去, 刪除此數據
//                            PushDataStorage.save(
//                                    registrar!!.activity(),
//                                    PushDataStorage.KEY_DEVICE_TOKEN,
//                                    null
//                            )
//                        }
//
//                        override fun error(s: String, s1: String?, o: Any?) {
//
//                        }
//
//                        override fun notImplemented() {
//
//                        }
//                    })
//                }
//
//                // 檢查缓存是否存在推送資料, 若存在回调
//                val umsgPushMsg = PushDataStorage.load(registrar!!.activity(), PushDataStorage.KEY_DEVICE_TOKEN)
//                if (umsgPushMsg != null && umsgPushMsg != "") {
//                    channel!!.invokeMethod("onMessage", umsgPushMsg, object : Result {
//                        override fun success(o: Any?) {
//                            /// 推送資料 成功回調出去, 刪除此數據
//                            PushDataStorage.save(
//                                    registrar!!.activity(),
//                                    PushDataStorage.KEY_PUSH_MESSAGE,
//                                    null
//                            )
//                        }
//
//                        override fun error(s: String, s1: String?, o: Any?) {
//
//                        }
//
//                        override fun notImplemented() {
//
//                        }
//                    })
//                }
                result.success(null)
            }
            FlutterCall.setMiPush -> {
                val appKey = call.argument<String>("appKey")
                val appId = call.argument<String>("appId")
                if (appKey != null && appId != null) {
                    println("設置小米推送 appKey = $appKey, appId = $appId")
                    PushManager.getInstance().setMi(appId, appKey)
                    result.success(null)
                } else {
                    println("設置小米推送失敗 appKey = $appKey, appId = $appId")
                    result.error("設置小米推送失敗", null, null)
                }
            }
            FlutterCall.setPushEnable -> {
                val isEnable = call.arguments<Boolean>()
                if (isEnable != null) {
                    println("設置推送開關 = $isEnable")
                    if (isEnable) {
                        PushManager.getInstance().init()
                    } else {
                        PushManager.getInstance().release()
                    }
                    PushManager.getInstance().isEnabled = isEnable
                    result.success(null)
                } else {
                    println("設置推送開關失敗, 請先設置 enable 參數")
                    result.error("設置推送開關失敗, 請先設置 enable 參數", null, null)
                }
            }
            FlutterCall.isPushEnable -> {
                result.success(PushManager.getInstance().isEnabled)
            }
            else -> {
                result.notImplemented()
            }
        }
    }


    /// 回調消息給 flutter
    fun flutterBack(method: String, arguments: Any?) {
        channel?.invokeMethod(method, arguments)
    }


}

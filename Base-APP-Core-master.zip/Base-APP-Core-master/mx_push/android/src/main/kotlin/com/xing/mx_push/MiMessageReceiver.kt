package com.xing.mx_push

import com.xiaomi.mipush.sdk.PushMessageReceiver
import com.xiaomi.mipush.sdk.ErrorCode
import com.xiaomi.mipush.sdk.MiPushClient
import com.xiaomi.mipush.sdk.MiPushCommandMessage
import android.content.Intent
import android.content.Context
import com.xiaomi.mipush.sdk.MiPushMessage
import com.xing.mx_push.mi.MiExtraKeys
import com.xing.mx_push.mi.MiReceiveActions


/// 小米廣播接收
class MiMessageReceiver : PushMessageReceiver() {

    private var mRegisterId: String? = null

    /// 透傳消息
    /// 通過參數 message 從而獲得透傳消息
    override fun onReceivePassThroughMessage(p0: Context?, p1: MiPushMessage?) {
        super.onReceivePassThroughMessage(p0, p1)
        println("小米推送(透傳): ${p1.toString()}")
        p1?.toBundle()
        val intent = Intent()
        intent.setPackage(p0?.packageName)
        intent.action = MiReceiveActions.message
        intent.putExtra(MiExtraKeys.message, p1.toString())
        p0?.sendBroadcast(intent)
    }

    /// 通知消息到達客戶端時調用
    /// 即使設置了應用在前台不彈出通知, 也會回調
    /// 通過參數 message 從而獲得透傳消息
    override fun onNotificationMessageArrived(p0: Context?, p1: MiPushMessage?) {
        super.onNotificationMessageArrived(p0, p1)
        println("小米推送(通知): ${p1.toString()}")

        val intent = Intent()
        intent.setPackage(p0?.packageName)
        intent.action = MiReceiveActions.notification
        intent.putExtra(MiExtraKeys.message, p1.toString())
        p0?.sendBroadcast(intent)
    }

    /// 用戶點擊通知欄消息調用
    /// 即使設置了應用在前台不彈出通知, 也會回調
    /// 通過參數 message 從而獲得透傳消息
    /// 設置用戶點擊後的動作 - 打開應用 or 網頁 or 其他頁面
    override fun onNotificationMessageClicked(p0: Context?, p1: MiPushMessage?) {
        super.onNotificationMessageClicked(p0, p1)

        println("用戶點擊了通知消息: ${p1.toString()}")

//        val component = ComponentName(p0!!.packageName, "")
//        val intent = Intent()
//        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//        intent.component = component
//        if (p1 != null) {
//            intent.putExtras(p1.toBundle())
//        }
//        p0.startActivity(intent)
    }

    /// 接收客戶端像伺服器發送命令後的結果
    override fun onCommandResult(p0: Context?, p1: MiPushCommandMessage?) {
        super.onCommandResult(p0, p1)
        if (p1 == null) {
            println("小米命令結果: null")
            return
        }
        val command = p1.command
        val arguments = p1.commandArguments
        val cmdArg1 = if (arguments != null && arguments.size > 0) arguments[0] else null
        val cmdArg2 = if (arguments != null && arguments.size > 1) arguments[1] else null
        if (MiPushClient.COMMAND_REGISTER == command) {
            if (p1.resultCode == ErrorCode.SUCCESS.toLong()) {
                mRegisterId = cmdArg1
                println("小米註冊成功: registerId = $cmdArg1")
            }
        } else if (MiPushClient.COMMAND_SET_ALIAS == command) {
            if (p1.resultCode == ErrorCode.SUCCESS.toLong()) {
            }
        } else if (MiPushClient.COMMAND_UNSET_ALIAS == command) {
            if (p1.resultCode == ErrorCode.SUCCESS.toLong()) {
            }
        } else if (MiPushClient.COMMAND_SUBSCRIBE_TOPIC == command) {
            if (p1.resultCode == ErrorCode.SUCCESS.toLong()) {
            }
        } else if (MiPushClient.COMMAND_UNSUBSCRIBE_TOPIC == command) {
            if (p1.resultCode == ErrorCode.SUCCESS.toLong()) {
            }
        } else if (MiPushClient.COMMAND_SET_ACCEPT_TIME == command) {
            if (p1.resultCode == ErrorCode.SUCCESS.toLong()) {
            }
        }

    }

    /// 接收向伺服器註冊推送的結果
    override fun onReceiveRegisterResult(p0: Context?, p1: MiPushCommandMessage?) {
        super.onReceiveRegisterResult(p0, p1)

        val command = p1?.command
        if (MiPushClient.COMMAND_REGISTER == command) {
            var isSuccess = p1.resultCode == ErrorCode.SUCCESS.toLong()
            if (isSuccess) {
                println("小米推送註冊成功")
            } else {
                println("小米推送註冊失敗")
            }
            val intent = Intent()
            intent.setPackage(p0?.packageName)
            intent.action = MiReceiveActions.register
            intent.putExtra(MiExtraKeys.success, isSuccess)
            intent.putExtra(MiExtraKeys.registerId, mRegisterId)
            p0?.sendBroadcast(intent)
        } else {
            println("小米命令結果: $command")
        }
    }
}
package com.xing.mx_push.mi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

abstract class MiPushReceiver: BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
            MiReceiveActions.register -> {
                val isSuccess = intent.getBooleanExtra(MiExtraKeys.success, false)
                val registerId = intent.getStringExtra(MiExtraKeys.registerId)
                registerComplete(isSuccess, registerId)
            }
            MiReceiveActions.message -> {
                val message = intent.getStringExtra(MiExtraKeys.message)
                receiveMessage(message)
            }
            MiReceiveActions.notification -> {
                val message = intent.getStringExtra(MiExtraKeys.message)
                receiveNotification(message)
            }
        }
    }

    /// 推送註冊是否成功
    abstract fun registerComplete(success: Boolean, registerId: String?)

    /// 推送收到通知
    abstract fun receiveMessage(message: String)

    /// 推送收到透傳消息
    abstract fun receiveNotification(message: String)
}
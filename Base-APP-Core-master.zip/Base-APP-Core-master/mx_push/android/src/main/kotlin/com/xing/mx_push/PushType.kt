package com.xing.mx_push

/// 推送管道
enum class PushType {
    MI,
}
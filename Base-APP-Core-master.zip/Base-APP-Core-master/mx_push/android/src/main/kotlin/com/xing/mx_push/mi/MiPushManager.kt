package com.xing.mx_push.mi

import android.content.Context
import com.xiaomi.mipush.sdk.MiPushClient
import android.content.IntentFilter
import com.xing.mx_push.*

class MiReceiveActions {
    companion object {
        const val notification = "receiveNotification"
        const val register = "register"
        const val message = "receiveMessage"
    }
}

class MiExtraKeys {
    companion object {
        const val message = "message"
        const val success = "success"
        const val registerId = "registerId"
    }
}

class MiPushManager(override val config: MiPushConfig) : VendorPushProtocol<MiPushConfig> {
    override fun init() {
        registerReceiver(true)
    }

    override fun release() {
        registerReceiver(false)
    }

    private val actions = listOf(
            MiReceiveActions.notification,
            MiReceiveActions.register,
            MiReceiveActions.message)

    override val context: Context
        get() = PushApplication.instance.applicationContext

    override var isEnabled: Boolean
        get() {
            return PushDataStorage.getState()
        }
        set(value) {
            if (value) {
                println("啟動小米推送")
                MiPushClient.registerPush(context, config.appId, config.appKey)
            } else {
                println("關閉小米推送")
                MiPushClient.unregisterPush(context)
            }
        }
    override val type: PushType
        get() = PushType.MI

    private fun registerReceiver(register: Boolean) {
        if (register) {
            val filter = IntentFilter()
            actions.forEach { filter.addAction(it) }
            context.registerReceiver(receiver, filter)
        } else {
            context.unregisterReceiver(receiver)
        }
    }

    private var receiver = object : MiPushReceiver() {
        override fun registerComplete(success: Boolean, registerId: String?) {
            val stateText = if (success) "成功" else "失敗"
            println("小米推送註冊完成: $stateText")
            if (success && registerId != null) {
                MxPushPlugin.instance.flutterBack(FlutterBack.onToken, registerId)
            }
        }

        override fun receiveMessage(message: String) {
            println("小米透傳消息: $message")
            MxPushPlugin.instance.flutterBack(FlutterBack.onMessage, message)
        }

        override fun receiveNotification(message: String) {
            println("小米通知消息: $message")
            MxPushPlugin.instance.flutterBack(FlutterBack.onMessage, message)
        }

    }
}
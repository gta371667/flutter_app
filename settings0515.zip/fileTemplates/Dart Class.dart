#macro( d $str )
    #set( $result = '' )
    #foreach( $s in $str.split("_") )
        #set( $upper = $s.toUpperCase() )
        #set( $result = $result + $upper.toUpperCase().charAt(0) + $upper.toLowerCase().substring(1) )
    #end
    $result
#end
class #d($NAME) {

}
